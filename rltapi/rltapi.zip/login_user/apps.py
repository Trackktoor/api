from django.apps import AppConfig


class LoginUserConfig(AppConfig):
    name = 'login_user'
