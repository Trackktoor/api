from django.contrib import admin
from .models import *

admin.site.register(URL)
admin.site.register(URL_hash)