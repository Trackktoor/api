from django.contrib import admin
from .models import *

admin.site.register(project)
admin.site.register(new_project_request)
admin.site.register(new_consult_request)
